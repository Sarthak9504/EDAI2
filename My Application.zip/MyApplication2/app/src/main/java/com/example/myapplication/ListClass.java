package com.example.myapplication;

public class ListClass {
    String Pname;

    public ListClass(String pname) {
        this.Pname = pname;
    }

    public String getPname() {
        return Pname;
    }

    public void setPname(String pname) {
        Pname = pname;
    }
}
